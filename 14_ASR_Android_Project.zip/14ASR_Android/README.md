# 14-ASR Android project

This is an Android Studio WebView wrapper for the supplied `14_ASR_NEXT_GENERATION.html` game.

## Build an APK
1. Install Android Studio (stable) and Android SDK Platform 35.
2. Open this folder (`14ASR_Android`) in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio writes the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

The app starts in landscape immersive full-screen mode. JavaScript and WebView DOM storage are enabled so the game can retain its local browser state.

## Network note
The supplied game source calls a Supabase backend for player authentication, save slots, and leaderboard-related features, and also references online fonts/images. Those features require internet. The game shell and bundled HTML are packaged locally, but this build is not fully offline-capable until those backend-dependent features are replaced or removed and remote assets are bundled.

## Package
Application ID: `uz.asr.fourteen`
Display name: `14-ASR`
Minimum Android: 6.0 (API 23)
Target SDK: 35
